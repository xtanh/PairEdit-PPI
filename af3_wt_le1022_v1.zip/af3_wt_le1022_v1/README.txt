AF3 WT复合物预测输入：每条链 <=1022 aa，单点及多点替换。

local_json/：本地 AlphaFold 3 格式，每个复合物一个 JSON。使用 --input_dir 指向此目录；运行标准 data pipeline + inference。

MSA/template 字段未提供，交由 AF3 数据流程生成；这些不是已完成 MSA 的 inference-only 输入。种子固定为 1，可统一修改以增加种子。

server_json_batches/：AlphaFold Server 网页导入格式，每文件最多20个任务。与 local_json 是同一套任务，选择一种使用，不要重复预测。

complex_manifest.csv：去重的复合物列表、长度、来源、序列和文件路径。

sample_mapping.csv：每条原始任务样本对应的 complex_id、突变所在链及1-based替换位置。只向AF3输入WT序列。

同一无方向WT序列对只预测一次，A/B按序列字典序固定；同源二聚体仍包含两个拷贝。homodimer_chain_ambiguous=True时WT结构的A/B物理上等价，映射使用A为约定，不证明实验只突变一个拷贝。

WT_complexes.fasta：每个复合物两条链；unique_WT_chains.fasta：所有单链去重，可用于复用MSA。

来源：疾病、人群使用已清洗任务数据；SNOOPPI使用单点+同一条链多点替换扩展数据，沿用来源去重。插入、缺失和双方同时突变未纳入。

疾病、人群当前来源均为单点替换，未额外挖掘这两个来源中的多点突变。

只按原始序列长度筛选，没有截断或拼接。保留数据源提供的序列，不宣称逐条还原了原实验构建体、PTM、配体或天然化学计量。

标签和证据原样保留；本包用于结构预测准备，不重新定义结合减弱的标签，也不修改现有五折或benchmark结果。

每条链 <=1022 不等于总长 <=2000；总长可能为2001–2044。详见summary.json。

这些是总预测需求，尚未减去作者现成结构；未启动预测或向服务器提交数据。

结果交付请保留complex_id、mmCIF及置信度/PAE JSON，便于后续接触图与突变映射。

官方格式参考：
https://github.com/google-deepmind/alphafold3/blob/main/docs/input.md
https://github.com/google-deepmind/alphafold/blob/main/server/README.md
