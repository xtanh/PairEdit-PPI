"""Export WT-only AF3 jobs; never alter existing benchmark cohorts or folds."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'benchmarks/snooppi_structure_inventory'
OUT = BASE / 'af3_wt_le1022_v1'
AA = set('ACDEFGHIKLMNPQRSTVWY')

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

def main():
    OUT.mkdir(exist_ok=True)
    for sub in ['local_json', 'server_json_batches']:
        (OUT / sub).mkdir(exist_ok=True)
    inputs = {
        name: ROOT / f'benchmarks/esig_net/data_policy/prepared_v1/{name}.parquet'
        for name in ['disease', 'population']
    }
    inputs['snooppi'] = BASE / 'snooppi_single_multi_candidates.parquet'
    records, excluded, summaries = [], [], {}
    for name, path in inputs.items():
        df = pd.read_parquet(path)
        if name == 'snooppi':
            df = df[df.conservative_eligible].copy()
        start = len(df)
        before = len(records)
        for r in df.to_dict('records'):
            rid = r.get('record_id') or 'snooppi:' + r['pair_id']
            w, m, p = r['wt'], r['mut'], r['partner']
            assert r['label_before'] == 1
            assert len(w) == len(m) and all(set(s) <= AA for s in [w, m, p])
            changes = [(i + 1, a, b) for i, (a, b) in enumerate(zip(w, m)) if a != b]
            assert changes and r['label_change'] == 1 - r['label_after']
            if max(len(w), len(p)) > 1022:
                excluded.append(dict(dataset=name, record_id=rid, reason='chain_over_1022', wt_length=len(w), partner_length=len(p)))
                continue
            a, b = sorted([w, p])
            digest = sha(a + '|' + b)
            records.append(dict(dataset=name, record_id=rid, complex_id='wt_' + digest[:20],
                complex_sha256=digest, chain_A_sequence=a, chain_B_sequence=b,
                mutated_chain='A' if w == a else 'B', homodimer_chain_ambiguous=w == p,
                substitutions=';'.join(f'{aa}{pos}{bb}' for pos, aa, bb in changes),
                n_substitutions=len(changes), label_before=1, label_after=r['label_after'],
                label_change=r['label_change'], wt_sequence=w, mutant_sequence=m,
                partner_sequence=p, source_pair_id=r.get('pair_id', ''),
                source_wt_pair_id=r.get('wt_pair_id', ''), pubmed_ids=r.get('pubmed_ids', ''),
                feature_evidence=r.get('feature_evidence', ''),
                mutated_accession_or_entrez=r.get('mutated_uniprot_ids', r.get('mutated_entrez', '')),
                partner_accession_or_entrez=r.get('partner_uniprot_ids', r.get('partner_entrez', ''))))
        ds = pd.DataFrame(records[before:])
        summaries[name] = dict(input_rows=start, included_rows=len(ds), excluded_by_length=start-len(ds),
            single_substitution=int((ds.n_substitutions == 1).sum()),
            multi_substitution=int((ds.n_substitutions > 1).sum()),
            label0_retained=int((ds.label_change == 0).sum()),
            label1_disrupted=int((ds.label_change == 1).sum()), WT_complexes=ds.complex_id.nunique())
    rows = pd.DataFrame(records)
    assert not rows.duplicated(['dataset', 'record_id']).any()
    jobs, server = [], []
    for cid, group in rows.groupby('complex_id', sort=True):
        assert group.complex_sha256.nunique() == 1
        a, b = group.iloc[0][['chain_A_sequence', 'chain_B_sequence']]
        assert 0 < len(a) <= 1022 and 0 < len(b) <= 1022
        local = dict(name=cid, modelSeeds=[1], sequences=[
            {'protein': {'id': 'A', 'sequence': a}},
            {'protein': {'id': 'B', 'sequence': b}}], dialect='alphafold3', version=1)
        (OUT / 'local_json' / f'{cid}.json').write_text(json.dumps(local, indent=2) + '\n')
        entities = [{'proteinChain': {'sequence': a, 'count': 2}}] if a == b else [
            {'proteinChain': {'sequence': a, 'count': 1}}, {'proteinChain': {'sequence': b, 'count': 1}}]
        server.append(dict(name=cid, modelSeeds=['1'], sequences=entities, dialect='alphafoldserver', version=1))
        jobs.append(dict(complex_id=cid, complex_sha256=group.iloc[0].complex_sha256,
            chain_A_sequence=a, chain_B_sequence=b, chain_A_sha256=sha(a), chain_B_sha256=sha(b),
            length_A=len(a), length_B=len(b), total_length=len(a)+len(b), homodimer=a == b,
            datasets=';'.join(sorted(group.dataset.unique())), n_source_rows=len(group),
            local_json=f'local_json/{cid}.json'))
    for offset in range(0, len(server), 20):
        (OUT / 'server_json_batches' / f'batch_{offset//20+1:04d}.json').write_text(json.dumps(server[offset:offset+20], indent=2)+'\n')
    manifest = pd.DataFrame(jobs)
    manifest.to_csv(OUT / 'complex_manifest.csv', index=False)
    rows.to_csv(OUT / 'sample_mapping.csv', index=False)
    pd.DataFrame(excluded).to_csv(OUT / 'excluded_by_length.csv', index=False)
    seqs = sorted(set(rows.wt_sequence) | set(rows.partner_sequence))
    (OUT / 'unique_WT_chains.fasta').write_text(''.join(f'>{sha(s)} length={len(s)}\n{s}\n' for s in seqs))
    with (OUT / 'WT_complexes.fasta').open('w') as f:
        for j in jobs:
            for chain in ['A', 'B']:
                f.write(f'>{j["complex_id"]}|{chain}\n{j[f"chain_{chain}_sequence"]}\n')
    # Check exported payloads against both source sequences and mutation coordinates.
    for r in rows.itertuples():
        assert getattr(r, f'chain_{r.mutated_chain}_sequence') == r.wt_sequence
        x = list(r.wt_sequence)
        for change in r.substitutions.split(';'):
            pos = int(change[1:-1]) - 1
            assert x[pos] == change[0]
            x[pos] = change[-1]
        assert ''.join(x) == r.mutant_sequence
    assert len(list((OUT / 'local_json').glob('*.json'))) == len(jobs)
    for j in jobs:
        obj = json.loads((OUT / j['local_json']).read_text())
        assert [x['protein']['sequence'] for x in obj['sequences']] == [j['chain_A_sequence'], j['chain_B_sequence']]
    decoded = [j for p in sorted((OUT / 'server_json_batches').glob('*.json')) for j in json.loads(p.read_text())]
    assert decoded == server
    summary = dict(per_dataset=summaries, total_source_rows=len(rows), unique_WT_complexes=len(jobs),
        unique_WT_chains=len(seqs), homodimer_complexes=int(manifest.homodimer.sum()),
        max_chain_length=int(max(manifest.length_A.max(), manifest.length_B.max())),
        max_total_length=int(manifest.total_length.max()),
        total_length_over2000=int((manifest.total_length > 2000).sum()),
        input_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.values()},
        validation='All job sequences, length constraints, mutation reconstruction, mapping and both JSON dialects checked; no AF3 inference run.')
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    (OUT / 'README.txt').write_text('''AF3 WT复合物预测输入：每条链 <=1022 aa，单点及多点替换。\n
local_json/：本地 AlphaFold 3 格式，每个复合物一个 JSON。使用 --input_dir 指向此目录；运行标准 data pipeline + inference。\n
MSA/template 字段未提供，交由 AF3 数据流程生成；这些不是已完成 MSA 的 inference-only 输入。种子固定为 1，可统一修改以增加种子。\n
server_json_batches/：AlphaFold Server 网页导入格式，每文件最多20个任务。与 local_json 是同一套任务，选择一种使用，不要重复预测。\n
complex_manifest.csv：去重的复合物列表、长度、来源、序列和文件路径。\n
sample_mapping.csv：每条原始任务样本对应的 complex_id、突变所在链及1-based替换位置。只向AF3输入WT序列。\n
同一无方向WT序列对只预测一次，A/B按序列字典序固定；同源二聚体仍包含两个拷贝。homodimer_chain_ambiguous=True时WT结构的A/B物理上等价，映射使用A为约定，不证明实验只突变一个拷贝。\n
WT_complexes.fasta：每个复合物两条链；unique_WT_chains.fasta：所有单链去重，可用于复用MSA。\n
来源：疾病、人群使用已清洗任务数据；SNOOPPI使用单点+同一条链多点替换扩展数据，沿用来源去重。插入、缺失和双方同时突变未纳入。\n
疾病、人群当前来源均为单点替换，未额外挖掘这两个来源中的多点突变。\n
只按原始序列长度筛选，没有截断或拼接。保留数据源提供的序列，不宣称逐条还原了原实验构建体、PTM、配体或天然化学计量。\n
标签和证据原样保留；本包用于结构预测准备，不重新定义结合减弱的标签，也不修改现有五折或benchmark结果。\n
每条链 <=1022 不等于总长 <=2000；总长可能为2001–2044。详见summary.json。\n
这些是总预测需求，尚未减去作者现成结构；未启动预测或向服务器提交数据。\n
结果交付请保留complex_id、mmCIF及置信度/PAE JSON，便于后续接触图与突变映射。\n
官方格式参考：\nhttps://github.com/google-deepmind/alphafold3/blob/main/docs/input.md\nhttps://github.com/google-deepmind/alphafold/blob/main/server/README.md\n''')
    shutil.copy2(__file__, OUT / Path(__file__).name)
    hashes = {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.rglob('*')) if p.is_file() and p.name != 'SHA256SUMS'}
    (OUT / 'SHA256SUMS').write_text(''.join(f'{h}  {p}\n' for p, h in hashes.items()))
    archive = BASE / (OUT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():
                z.write(p, str(Path(OUT.name) / p.relative_to(OUT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    print(json.dumps(summary, indent=2))
    print('Archive:', archive, 'bytes:', archive.stat().st_size)

if __name__ == '__main__':
    main()
